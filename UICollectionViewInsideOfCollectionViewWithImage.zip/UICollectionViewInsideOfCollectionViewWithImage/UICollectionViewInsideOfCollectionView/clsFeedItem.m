//
//  clsFeedItem.m
//  UICollectionViewInsideOfCollectionView
//
//  Created by Evan on 2015/10/7.
//  Copyright (c) 2015年 Evan. All rights reserved.
//

#import "clsFeedItem.h"

@implementation clsFeedItem
@synthesize imagePath;
@synthesize text;
@end
