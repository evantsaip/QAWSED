//
//  NumberCell2.m
//  UICollectionViewInsideOfCollectionView
//
//  Created by Evan on 2015/10/6.
//  Copyright (c) 2015年 Evan. All rights reserved.
//

#import "NumberCell2.h"
@implementation NumberCell2
-(void)LoadCell:(clsFeedItem *)FeedItem{
    [txttext setText:FeedItem.text];
    [imagePicture setImage:[UIImage imageNamed:FeedItem.imagePath]];
    
}

@end
