//
//  NumberCell.m
//  UICollectionViewInsideOfCollectionView
//
//  Created by Evan on 2015/10/6.
//  Copyright (c) 2015年 Evan. All rights reserved.
//

#import "NumberCell.h"
#import "NumberCell2.h"
@implementation NumberCell

- (void)LoadCell:(NSString *)Number{
    [txtNumber setText:Number];
    items2 = [[NSMutableArray alloc]init];
    [items2 addObject:@"1"];
    [items2 addObject:@"2"];
    [items2 addObject:@"3"];
    [items2 addObject:@"4"];
    [items2 addObject:@"5"];
    [items2 addObject:@"6"];
    [items2 addObject:@"7"];
    [items2 addObject:@"8"];
    [items2 addObject:@"9"];
    [items2 addObject:@"10"];
    [items2 addObject:@"11"];
    [items2 addObject:@"12"];
    [itemstable2 setDelegate:self];
    [itemstable2 setDataSource:self];
    [itemstable2 reloadData];
}
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return items2.count;
}
-(UICollectionViewCell*)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    NSString *buf2 = items2[indexPath.row];
    NumberCell2 *cell = (NumberCell2*)[collectionView dequeueReusableCellWithReuseIdentifier:@"numberCell2" forIndexPath:indexPath];
    [cell LoadCell:buf2];
    return cell;
}

@end

