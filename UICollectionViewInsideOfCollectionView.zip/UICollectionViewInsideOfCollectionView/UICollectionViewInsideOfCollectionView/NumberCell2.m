//
//  NumberCell2.m
//  UICollectionViewInsideOfCollectionView
//
//  Created by Evan on 2015/10/6.
//  Copyright (c) 2015年 Evan. All rights reserved.
//

#import "NumberCell2.h"
@implementation NumberCell2
-(void)LoadCell:(NSString *)Number2{
    [txtNumber2 setText:Number2];
}

@end
