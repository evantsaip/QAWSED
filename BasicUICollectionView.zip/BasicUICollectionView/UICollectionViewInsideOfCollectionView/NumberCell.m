//
//  NumberCell.m
//  UICollectionViewInsideOfCollectionView
//
//  Created by Evan on 2015/10/6.
//  Copyright (c) 2015年 Evan. All rights reserved.
//

#import "NumberCell.h"

@implementation NumberCell

- (void)LoadCell:(NSString *)Number{
    [txtNumber setText:Number];
}
@end
