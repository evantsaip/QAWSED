//
//  MyXibView.h
//  UICollectionViewInsideOfCollectionView
//
//  Created by Evan on 2015/10/8.
//  Copyright (c) 2015年 Evan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ViewController.h"
#import "NumberCell.h"
#import "NumberCell2.h"
#import "clsFeedItem.h"
@interface MyXibView : UIView
- (IBAction)hello:(id)sender;
- (IBAction)detailViewturn:(id)sender;

@end
