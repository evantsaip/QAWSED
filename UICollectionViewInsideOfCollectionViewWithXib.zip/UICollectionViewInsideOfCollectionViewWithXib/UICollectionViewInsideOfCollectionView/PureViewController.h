//
//  PureViewController.h
//  UICollectionViewInsideOfCollectionView
//
//  Created by Evan on 2015/10/8.
//  Copyright (c) 2015年 Evan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PureViewController : UIViewController

@end
