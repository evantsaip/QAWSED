//
//  MyXibViewController.h
//  UICollectionViewInsideOfCollectionView
//
//  Created by Evan on 2015/10/7.
//  Copyright (c) 2015年 Evan. All rights reserved.
//

#import "ViewController.h"
#import "CellViewController.h"

@interface MyXibViewController : ViewController
//- (IBAction)detailViewReturnBtn:(id)sender;
//
//- (IBAction)printWords:(id)sender;
@end




